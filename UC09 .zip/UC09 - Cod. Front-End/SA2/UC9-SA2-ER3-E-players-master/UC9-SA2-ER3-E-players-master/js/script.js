// function mostrarPopup(){
//     window.alert("Hello World")
// }

let email = document.getElementById("campo-email");

function enviarEmail(){
    let emailDigitado = email.value;
    console.log(emailDigitado)
}