function topzera() {
    alert("Muito TOP")
}

// alert("Salve");