import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contat',
  templateUrl: './contat.component.html',
  styleUrls: ['./contat.component.css']
})
export class ContatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
